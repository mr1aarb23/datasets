from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class DataIngestionConfig:
    root_dir: Path
    source_URL: str
    local_data_file: Path
    unzip_dir: Path


@dataclass(frozen=True)
class DataValidationConfig:
    root_dir: Path
    STATUS_FILE: str
    unzip_data_dir: Path
    all_schema: dict


@dataclass(frozen=True)
class DataTransformationconfig:
    root_dir: Path
    data_path: Path
    horizon: int

##################### Models #####################

@dataclass(frozen=True)
class ModelTrainerConfig_LR:
    root_dir: Path
    X_train_data_path : Path
    y_train_data_path : Path
    model_name : str
    model_dir_name : str
    runtime_name : str
    
@dataclass(frozen=True)
class ModelTrainerConfig_SVR:
    root_dir: Path
    model_dir_name: str
    X_train_data_path : Path
    y_train_data_path : Path
    X_test_data_path : Path
    y_test_data_path : Path
    model_name : str
    x_scaler_name : str
    y_scaler_name : str
    c : float
    gamma : float
    runtime_name : str


@dataclass(frozen=True)
class ModelTrainerConfig_XGBoost:
    root_dir: Path
    model_dir_name: str
    X_train_data_path : Path
    y_train_data_path : Path
    X_test_data_path : Path
    y_test_data_path : Path
    model_name : str
    x_scaler_name : str
    y_scaler_name : str
    runtime_name : str
    n_estimators : int
    early_stopping_rounds : int
    
@dataclass(frozen=True)
class ModelTrainerConfig_CNN:
    root_dir: Path
    model_dir_name: str
    X_train_data_path : Path
    y_train_data_path : Path
    X_test_data_path : Path
    y_test_data_path : Path
    model_name : str
    x_scaler_name : str
    y_scaler_name : str
    runtime_name : str
    horizon : int
    early_stopping : int
    epochs : int
    learning_rate : int

@dataclass(frozen=True)
class ModelTrainerConfig_LSTM:
    root_dir: Path
    model_dir_name: str
    X_train_data_path : Path
    y_train_data_path : Path
    X_test_data_path : Path
    y_test_data_path : Path
    model_name : str
    x_scaler_name : str
    y_scaler_name : str
    runtime_name : str
    horizon : int
    early_stopping : int
    epochs : int
    learning_rate : int


@dataclass(frozen=True)
class ModelTrainerConfig_GRU:
    root_dir: Path
    model_dir_name: str
    X_train_data_path : Path
    y_train_data_path : Path
    X_test_data_path : Path
    y_test_data_path : Path
    model_name : str
    x_scaler_name : str
    y_scaler_name : str
    runtime_name : str
    horizon : int
    early_stopping : int
    epochs : int
    learning_rate : int


##################### Models #####################
@dataclass(frozen=True)
class ModelEvaluationConfig_LR:
    root_dir : Path
    model_dir_name:str
    X_test_data_path : Path
    y_test_data_path : Path
    model_path : Path
    metric_file : Path
    mlflow_uri : str
    
@dataclass(frozen=True)
class ModelEvaluationConfig_SVR:
    root_dir : Path
    model_dir_name : str 
    X_test_data_path : Path
    y_test_data_path : Path
    X_test_scaled_data_path : Path
    y_test_scaled_data_path : Path
    model_path : Path
    y_scaler_path : Path
    all_params : dict
    metric_file : Path
    mlflow_uri : str
    
@dataclass(frozen=True)
class ModelEvaluationConfig_XGBoost:
    root_dir : Path
    model_dir_name : str 
    X_test_data_path : Path
    y_test_data_path : Path
    X_test_scaled_data_path : Path
    y_test_scaled_data_path : Path
    model_path : Path
    y_scaler_path : Path
    all_params : dict
    metric_file : Path
    mlflow_uri : str
    
@dataclass(frozen=True)
class ModelEvaluationConfig_CNN:
    root_dir : Path
    model_dir_name : str 
    X_test_data_path : Path
    y_test_data_path : Path
    X_test_scaled_data_path : Path
    y_test_scaled_data_path : Path
    model_path : Path
    y_scaler_path : Path
    all_params : dict
    metric_file : Path
    mlflow_uri : str
    
@dataclass(frozen=True)
class ModelEvaluationConfig_LSTM:
    root_dir : Path
    model_dir_name : str 
    X_test_data_path : Path
    y_test_data_path : Path
    X_test_scaled_data_path : Path
    y_test_scaled_data_path : Path
    model_path : Path
    y_scaler_path : Path
    all_params : dict
    metric_file : Path
    mlflow_uri : str
    

@dataclass(frozen=True)
class ModelEvaluationConfig_GRU:
    root_dir : Path
    model_dir_name : str 
    X_test_data_path : Path
    y_test_data_path : Path
    X_test_scaled_data_path : Path
    y_test_scaled_data_path : Path
    model_path : Path
    y_scaler_path : Path
    all_params : dict
    metric_file : Path
    mlflow_uri : str