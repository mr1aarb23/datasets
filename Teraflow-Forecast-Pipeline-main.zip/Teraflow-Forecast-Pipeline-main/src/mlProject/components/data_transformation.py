import os
from src.mlProject.utils import logger
from src.mlProject.entity.config_entity import DataTransformationconfig
from sklearn.model_selection import train_test_split
import pandas as pd

class DataTransformation:
    def __init__(self,config: DataTransformationconfig):
        self.config = config
        
    
        
    def data_windowing(self):
        df = pd.read_csv(self.config.data_path)
        combined_df = pd.DataFrame()
        for s in df['store'].unique():
            for p in df['product'].unique():
                data = df[(df['product'] == p )& (df['store'] == s )].copy()
                for i in range(self.config.horizon):
                    data[f'Y (t+{self.config.horizon-i})'] = data['number_sold'].shift(i)

                for i in range(self.config.horizon,2*self.config.horizon):
                    data[f'X (t-{i-self.config.horizon})'] = data['number_sold'].shift(i)

                data.dropna(inplace=True)
                combined_df = pd.concat([combined_df, data], ignore_index=True)

            combined_df = combined_df.iloc[:,::-1]
            X = combined_df.iloc[:, list(range(self.config.horizon)) + list(range(self.config.horizon*2+1, len(combined_df.columns)-1))]
            y = combined_df.iloc[:, self.config.horizon: self.config.horizon*2]
                
        combined_df.to_csv(os.path.join(self.config.root_dir,"data.csv"),index=False)
        return X,y
            
    def train_test_spliting(self,X,y):

        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        X_train.to_csv(os.path.join(self.config.root_dir,"X_train.csv"),index=False)
        X_test.to_csv(os.path.join(self.config.root_dir,"X_test.csv"),index=False)
        y_train.to_csv(os.path.join(self.config.root_dir,"y_train.csv"),index=False)
        y_test.to_csv(os.path.join(self.config.root_dir,"y_test.csv"),index=False)
        
        logger.info("Splited data into training and test  sets")
        logger.info(X_train.shape)
        logger.info(y_train.shape)
        logger.info(X_test.shape)
        logger.info(y_test.shape)
        
        print(X_train.shape)
        print(y_train.shape)
        print(X_test.shape)
        print(y_test.shape)