import pandas as pd
import os
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error, mean_absolute_error
from urllib.parse import urlparse
import mlflow
import mlflow.sklearn
import joblib
import numpy as np
from src.mlProject.entity.config_entity import *
from pathlib import Path
from src.mlProject.utils.common import save_json
import tensorflow as tf


class ModelEvaluation_LR:
    def __init__(self, config: ModelEvaluationConfig_LR):
        self.config = config

    def eval_metrics(self, actual, pred):
        rmse = np.sqrt(mean_squared_error(actual, pred))
        mape = mean_absolute_percentage_error(actual, pred)
        mae = mean_absolute_error(actual, pred)
        mse = mean_squared_error(actual, pred)

        return rmse, mape, mae, mse

    def log_into_mlflow(self):
        y_test_data = np.array(pd.read_csv(self.config.y_test_data_path))

        X_test_data = np.array(pd.read_csv(self.config.X_test_data_path))

        model = joblib.load(self.config.model_path)

        mlflow.set_registry_uri(self.config.mlflow_uri)
        tracking_url_type_store = urlparse(mlflow.get_tracking_uri()).scheme

        with mlflow.start_run():

            forecast = model.predict(X_test_data)
            (rmse, mape, mae, mse) = self.eval_metrics(y_test_data, forecast)

            scores = {"rmse": rmse, "mape": mape, "mae": mae, "mse": mse}
            save_json(path=Path(self.config.metric_file), data=scores)

            mlflow.log_metric("rmse", rmse)
            mlflow.log_metric("mape", mape)
            mlflow.log_metric("mae", mae)
            mlflow.log_metric("mse", mse)

            if tracking_url_type_store != "file":
                mlflow.sklearn.log_model(
                    model, "model", registered_model_name="Linear Regression")
            else:
                mlflow.sklearn.log_model(model, "model")


class ModelEvaluation_SVR:
    def __init__(self, config: ModelEvaluationConfig_SVR):
        self.config = config

    def eval_metrics(self, actual, pred):
        rmse = np.sqrt(mean_squared_error(actual, pred))
        mape = mean_absolute_percentage_error(actual, pred)
        mae = mean_absolute_error(actual, pred)
        mse = mean_squared_error(actual, pred)

        return rmse, mape, mae, mse

    def log_into_mlflow(self):
        y_test_data = np.array(pd.read_csv(self.config.y_test_data_path))

        X_test_scaled_data = np.array(pd.read_csv(
            self.config.X_test_scaled_data_path, header=None))

        model = joblib.load(self.config.model_path)
        y_std = joblib.load(self.config.y_scaler_path)

        mlflow.set_registry_uri(self.config.mlflow_uri)
        tracking_url_type_store = urlparse(mlflow.get_tracking_uri()).scheme

        with mlflow.start_run():

            forecast = model.predict(X_test_scaled_data)
            real_forecast = y_std.inverse_transform(forecast)
            (rmse, mape, mae, mse) = self.eval_metrics(
                y_test_data, real_forecast)

            scores = {"rmse": rmse, "mape": mape, "mae": mae, "mse": mse}
            save_json(path=Path(self.config.metric_file), data=scores)

            mlflow.log_params(self.config.all_params)

            mlflow.log_metric("rmse", rmse)
            mlflow.log_metric("mape", mape)
            mlflow.log_metric("mae", mae)
            mlflow.log_metric("mse", mse)

            if tracking_url_type_store != "file":
                mlflow.sklearn.log_model(
                    model, "model", registered_model_name="SVR")
            else:
                mlflow.sklearn.log_model(model, "model")


class ModelEvaluation_XGBoost:
    def __init__(self, config: ModelEvaluationConfig_XGBoost):
        self.config = config

    def eval_metrics(self, actual, pred):
        rmse = np.sqrt(mean_squared_error(actual, pred))
        mape = mean_absolute_percentage_error(actual, pred)
        mae = mean_absolute_error(actual, pred)
        mse = mean_squared_error(actual, pred)

        return rmse, mape, mae, mse

    def log_into_mlflow(self):
        y_test_data = np.array(pd.read_csv(self.config.y_test_data_path))

        X_test_scaled_data = np.array(pd.read_csv(
            self.config.X_test_scaled_data_path, header=None))

        model = joblib.load(self.config.model_path)
        y_std = joblib.load(self.config.y_scaler_path)

        mlflow.set_registry_uri(self.config.mlflow_uri)
        tracking_url_type_store = urlparse(mlflow.get_tracking_uri()).scheme

        with mlflow.start_run():

            forecast = model.predict(X_test_scaled_data)
            real_forecast = y_std.inverse_transform(forecast)
            (rmse, mape, mae, mse) = self.eval_metrics(
                y_test_data, real_forecast)

            scores = {"rmse": rmse, "mape": mape, "mae": mae, "mse": mse}
            save_json(path=Path(self.config.metric_file), data=scores)

            mlflow.log_params(self.config.all_params)

            mlflow.log_metric("rmse", rmse)
            mlflow.log_metric("mape", mape)
            mlflow.log_metric("mae", mae)
            mlflow.log_metric("mse", mse)

            if tracking_url_type_store != "file":
                mlflow.sklearn.log_model(
                    model, "model", registered_model_name="XGBoost")
            else:
                mlflow.sklearn.log_model(model, "model")


class ModelEvaluation_CNN:
    def __init__(self, config: ModelEvaluationConfig_CNN):
        self.config = config

    def eval_metrics(self, actual, pred):
        rmse = np.sqrt(mean_squared_error(actual, pred))
        mape = mean_absolute_percentage_error(actual, pred)
        mae = mean_absolute_error(actual, pred)
        mse = mean_squared_error(actual, pred)

        return rmse, mape, mae, mse

    def log_into_mlflow(self):
        y_test_data = np.array(pd.read_csv(self.config.y_test_data_path))

        X_test_scaled_data = np.array(pd.read_csv(
            self.config.X_test_scaled_data_path, header=None))

        model = tf.keras.models.load_model(self.config.model_path)
        y_std = joblib.load(self.config.y_scaler_path)

        mlflow.set_registry_uri(self.config.mlflow_uri)
        tracking_url_type_store = urlparse(mlflow.get_tracking_uri()).scheme

        with mlflow.start_run():

            forecast = model.predict(X_test_scaled_data)
            real_forecast = y_std.inverse_transform(forecast)
            (rmse, mape, mae, mse) = self.eval_metrics(
                y_test_data, real_forecast)

            scores = {"rmse": rmse, "mape": mape, "mae": mae, "mse": mse}
            save_json(path=Path(self.config.metric_file), data=scores)

            mlflow.log_params(self.config.all_params)

            mlflow.log_metric("rmse", rmse)
            mlflow.log_metric("mape", mape)
            mlflow.log_metric("mae", mae)
            mlflow.log_metric("mse", mse)

            if tracking_url_type_store != "file":
                mlflow.sklearn.log_model(
                    model, "model", registered_model_name="CNN")
            else:
                mlflow.sklearn.log_model(model, "model")


class ModelEvaluation_LSTM:
    def __init__(self, config: ModelEvaluationConfig_LSTM):
        self.config = config

    def eval_metrics(self, actual, pred):
        rmse = np.sqrt(mean_squared_error(actual, pred))
        mape = mean_absolute_percentage_error(actual, pred)
        mae = mean_absolute_error(actual, pred)
        mse = mean_squared_error(actual, pred)

        return rmse, mape, mae, mse

    def log_into_mlflow(self):
        y_test_data = np.array(pd.read_csv(self.config.y_test_data_path))

        X_test_scaled_data = np.array(pd.read_csv(
            self.config.X_test_scaled_data_path, header=None))

        model = tf.keras.models.load_model(self.config.model_path)
        y_std = joblib.load(self.config.y_scaler_path)

        mlflow.set_registry_uri(self.config.mlflow_uri)
        tracking_url_type_store = urlparse(mlflow.get_tracking_uri()).scheme

        with mlflow.start_run():

            forecast = model.predict(X_test_scaled_data)
            real_forecast = y_std.inverse_transform(forecast)
            (rmse, mape, mae, mse) = self.eval_metrics(
                y_test_data, real_forecast)

            scores = {"rmse": rmse, "mape": mape, "mae": mae, "mse": mse}
            save_json(path=Path(self.config.metric_file), data=scores)

            mlflow.log_params(self.config.all_params)

            mlflow.log_metric("rmse", rmse)
            mlflow.log_metric("mape", mape)
            mlflow.log_metric("mae", mae)
            mlflow.log_metric("mse", mse)

            if tracking_url_type_store != "file":
                mlflow.sklearn.log_model(
                    model, "model", registered_model_name="CNN")
            else:
                mlflow.sklearn.log_model(model, "model")


class ModelEvaluation_GRU:
    def __init__(self, config: ModelEvaluationConfig_GRU):
        self.config = config

    def eval_metrics(self, actual, pred):
        rmse = np.sqrt(mean_squared_error(actual, pred))
        mape = mean_absolute_percentage_error(actual, pred)
        mae = mean_absolute_error(actual, pred)
        mse = mean_squared_error(actual, pred)

        return rmse, mape, mae, mse

    def log_into_mlflow(self):
        y_test_data = np.array(pd.read_csv(self.config.y_test_data_path))

        X_test_scaled_data = np.array(pd.read_csv(
            self.config.X_test_scaled_data_path, header=None))

        model = tf.keras.models.load_model(self.config.model_path)
        y_std = joblib.load(self.config.y_scaler_path)

        mlflow.set_registry_uri(self.config.mlflow_uri)
        tracking_url_type_store = urlparse(mlflow.get_tracking_uri()).scheme

        with mlflow.start_run():

            forecast = model.predict(X_test_scaled_data)
            real_forecast = y_std.inverse_transform(forecast)
            (rmse, mape, mae, mse) = self.eval_metrics(
                y_test_data, real_forecast)

            scores = {"rmse": rmse, "mape": mape, "mae": mae, "mse": mse}
            save_json(path=Path(self.config.metric_file), data=scores)

            mlflow.log_params(self.config.all_params)

            mlflow.log_metric("rmse", rmse)
            mlflow.log_metric("mape", mape)
            mlflow.log_metric("mae", mae)
            mlflow.log_metric("mse", mse)

            if tracking_url_type_store != "file":
                mlflow.sklearn.log_model(
                    model, "model", registered_model_name="GRU")
            else:
                mlflow.sklearn.log_model(model, "model")
