import pandas as pd
import os
from src.mlProject.utils import logger
from sklearn.svm import SVR
from sklearn.multioutput import MultiOutputRegressor
import joblib
import numpy as np
from sklearn.preprocessing import StandardScaler
import time
from src.mlProject.entity.config_entity import ModelTrainerConfig_LR, ModelTrainerConfig_SVR, ModelTrainerConfig_XGBoost, ModelTrainerConfig_CNN, ModelTrainerConfig_LSTM, ModelTrainerConfig_GRU
from src.mlProject.utils.common import save_json
from pathlib import Path
from sklearn.linear_model import LinearRegression
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split

import pickle
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import Adam
from tensorflow.keras import layers
from tensorflow.keras.metrics import RootMeanSquaredError


class ModelTrainer_SVR:
    def __init__(self, config: ModelTrainerConfig_SVR):
        self.config = config

    def load_scale_data(self):
        X_train = np.array(pd.read_csv(self.config.X_train_data_path))
        y_train = np.array(pd.read_csv(self.config.y_train_data_path))
        X_test = np.array(pd.read_csv(self.config.X_test_data_path))
        y_test = np.array(pd.read_csv(self.config.y_test_data_path))

        std_x = StandardScaler()
        X_train_scaled = std_x.fit_transform(X_train)
        X_test_scaled = std_x.transform(X_test)

        std_y = StandardScaler()
        y_train_scaled = std_y.fit_transform(y_train)
        y_test_scaled = std_y.transform(y_test)

        np.savetxt(os.path.join(os.path.join(self.config.root_dir,
                   self.config.model_dir_name), "X_test_scaled.csv"), X_test_scaled, delimiter=',')
        np.savetxt(os.path.join(os.path.join(self.config.root_dir,
                   self.config.model_dir_name), "y_test_scaled.csv"), y_test_scaled, delimiter=',')

        joblib.dump(std_x, os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), self.config.x_scaler_name))
        joblib.dump(std_y, os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), self.config.y_scaler_name))

        return X_train_scaled, y_train_scaled

    def train(self, X_train_scaled, y_train_scaled):
        svr = SVR(kernel='rbf', C=self.config.c, gamma=self.config.gamma)
        multioutput_svr = MultiOutputRegressor(svr)

        start_svr = time.time()
        multioutput_svr.fit(X_train_scaled, y_train_scaled)
        end_svr = time.time()

        training_time = end_svr - start_svr
        training_time = {"training time": training_time}
        save_json(path=Path(os.path.join(os.path.join(self.config.root_dir,
                  self.config.model_dir_name), self.config.runtime_name)), data=training_time)
        joblib.dump(multioutput_svr, os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), self.config.model_name))


class ModelTrainer_LR:
    def __init__(self, config: ModelTrainerConfig_LR):
        self.config = config

    def load_data(self):
        X_train = np.array(pd.read_csv(self.config.X_train_data_path))
        y_train = np.array(pd.read_csv(self.config.y_train_data_path))

        return X_train, y_train

    def train(self, X_train, y_train):
        lr = LinearRegression()
        start_lr = time.time()
        lr.fit(X_train, y_train)
        end_lr = time.time()

        joblib.dump(lr, os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), self.config.model_name))
        training_time = end_lr - start_lr
        training_time = {"training time": training_time}
        save_json(path=Path(os.path.join(os.path.join(self.config.root_dir,
                  self.config.model_dir_name), self.config.runtime_name)), data=training_time)


class ModelTrainer_XGBoost:
    def __init__(self, config: ModelTrainerConfig_XGBoost):
        self.config = config

    def load_scale_data(self):
        X_train = np.array(pd.read_csv(self.config.X_train_data_path))
        y_train = np.array(pd.read_csv(self.config.y_train_data_path))
        X_test = np.array(pd.read_csv(self.config.X_test_data_path))
        y_test = np.array(pd.read_csv(self.config.y_test_data_path))

        std_x = StandardScaler()
        X_train_scaled = std_x.fit_transform(X_train)
        X_test_scaled = std_x.transform(X_test)

        std_y = StandardScaler()
        y_train_scaled = std_y.fit_transform(y_train)
        y_test_scaled = std_y.transform(y_test)

        np.savetxt(os.path.join(os.path.join(self.config.root_dir,
                   self.config.model_dir_name), "X_test_scaled.csv"), X_test_scaled, delimiter=',')
        np.savetxt(os.path.join(os.path.join(self.config.root_dir,
                   self.config.model_dir_name), "y_test_scaled.csv"), y_test_scaled, delimiter=',')

        joblib.dump(std_x, os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), self.config.x_scaler_name))
        joblib.dump(std_y, os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), self.config.y_scaler_name))

        return X_train_scaled, y_train_scaled,

    def train(self, X_train_scaled, y_train_scaled):

        X_train, X_val, y_train, y_val = train_test_split(
            X_train_scaled, y_train_scaled, test_size=0.2, random_state=42)
        xgb = XGBRegressor(n_estimators=self.config.n_estimators,
                           early_stopping_rounds=self.config.early_stopping_rounds, eval_metric="rmse")

        start_xgboost = time.time()
        xgb.fit(X_train, y_train, eval_set=[
                (X_train, y_train), (X_val, y_val)], verbose=True)
        end_xgboost = time.time()

        training_time = end_xgboost - start_xgboost
        training_time = {"training time": training_time}
        save_json(path=Path(os.path.join(os.path.join(self.config.root_dir,
                  self.config.model_dir_name), self.config.runtime_name)), data=training_time)
        joblib.dump(xgb, os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), self.config.model_name))


class ModelTrainer_CNN:
    def __init__(self, config: ModelTrainerConfig_CNN):
        self.config = config

    def load_scale_data(self):
        X_train = np.array(pd.read_csv(self.config.X_train_data_path))
        y_train = np.array(pd.read_csv(self.config.y_train_data_path))
        X_test = np.array(pd.read_csv(self.config.X_test_data_path))
        y_test = np.array(pd.read_csv(self.config.y_test_data_path))

        std_x = StandardScaler()
        X_train_scaled = std_x.fit_transform(X_train)
        X_test_scaled = std_x.transform(X_test)

        std_y = StandardScaler()
        y_train_scaled = std_y.fit_transform(y_train)
        y_test_scaled = std_y.transform(y_test)

        np.savetxt(os.path.join(os.path.join(self.config.root_dir,
                   self.config.model_dir_name), "X_test_scaled.csv"), X_test_scaled, delimiter=',')
        np.savetxt(os.path.join(os.path.join(self.config.root_dir,
                   self.config.model_dir_name), "y_test_scaled.csv"), y_test_scaled, delimiter=',')

        joblib.dump(std_x, os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), self.config.x_scaler_name))
        joblib.dump(std_y, os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), self.config.y_scaler_name))

        return X_train_scaled, y_train_scaled

    def create_model(self, past_time_steps, future_time_steps):
        model = Sequential([
            layers.Input((past_time_steps+2, 1)),
            layers.Conv1D(64, kernel_size=2, activation='relu'),
            layers.Flatten(),
            layers.Dense(100, activation='relu'),
            layers.Dense(future_time_steps, activation='linear')
        ])

        # Compile the model
        optimizer = Adam(learning_rate=self.config.learning_rate)
        model.compile(loss='mse', optimizer=optimizer,
                      metrics=[RootMeanSquaredError()])

        return model

    def train(self, X_train_scaled, y_train_scaled):

        X_train, X_val, y_train, y_val = train_test_split(
            X_train_scaled, y_train_scaled, test_size=0.2, random_state=42)
        model = self.create_model(self.config.horizon, self.config.horizon)
        early_stopping = tf.keras.callbacks.EarlyStopping(
            monitor='val_loss', patience=self.config.early_stopping, mode='min')

        start_cnn = time.time()
        hist = model.fit(X_train, y_train, validation_data=(
            X_val, y_val), epochs=self.config.epochs, callbacks=[early_stopping])
        end_cnn = time.time()

        training_time = end_cnn - start_cnn
        training_time = {"training time": training_time}
        save_json(path=Path(os.path.join(os.path.join(self.config.root_dir,
                  self.config.model_dir_name), self.config.runtime_name)), data=training_time)
        model.save(os.path.join(os.path.join(self.config.root_dir,
                   self.config.model_dir_name), self.config.model_name))

        history_path = os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), 'training_history.pkl')

        with open(history_path, 'wb') as file:
            pickle.dump(hist.history, file)


class ModelTrainer_LSTM:
    def __init__(self, config: ModelTrainerConfig_LSTM):
        self.config = config

    def load_scale_data(self):
        X_train = np.array(pd.read_csv(self.config.X_train_data_path))
        y_train = np.array(pd.read_csv(self.config.y_train_data_path))
        X_test = np.array(pd.read_csv(self.config.X_test_data_path))
        y_test = np.array(pd.read_csv(self.config.y_test_data_path))

        std_x = StandardScaler()
        X_train_scaled = std_x.fit_transform(X_train)
        X_test_scaled = std_x.transform(X_test)

        std_y = StandardScaler()
        y_train_scaled = std_y.fit_transform(y_train)
        y_test_scaled = std_y.transform(y_test)

        np.savetxt(os.path.join(os.path.join(self.config.root_dir,
                   self.config.model_dir_name), "X_test_scaled.csv"), X_test_scaled, delimiter=',')
        np.savetxt(os.path.join(os.path.join(self.config.root_dir,
                   self.config.model_dir_name), "y_test_scaled.csv"), y_test_scaled, delimiter=',')

        joblib.dump(std_x, os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), self.config.x_scaler_name))
        joblib.dump(std_y, os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), self.config.y_scaler_name))

        return X_train_scaled, y_train_scaled

    def create_model(self, past_time_steps, future_time_steps):

        model = Sequential([layers.Input((past_time_steps+2, 1)),
                            layers.LSTM(128),
                            layers.Dense(64, activation='relu'),
                            layers.Dense(future_time_steps, activation='linear')])

        optimizer = Adam(learning_rate=self.config.learning_rate)
        model.compile(loss='mse', optimizer=optimizer,
                      metrics=[RootMeanSquaredError()])

        return model

    def train(self, X_train_scaled, y_train_scaled):

        X_train, X_val, y_train, y_val = train_test_split(
            X_train_scaled, y_train_scaled, test_size=0.2, random_state=42)
        model = self.create_model(self.config.horizon, self.config.horizon)
        early_stopping = tf.keras.callbacks.EarlyStopping(
            monitor='val_loss', patience=self.config.early_stopping, mode='min')

        start_lstm = time.time()
        hist = model.fit(X_train, y_train, validation_data=(
            X_val, y_val), epochs=self.config.epochs, callbacks=[early_stopping])
        end_lstm = time.time()

        training_time = end_lstm - start_lstm
        training_time = {"training time": training_time}
        save_json(path=Path(os.path.join(os.path.join(self.config.root_dir,
                  self.config.model_dir_name), self.config.runtime_name)), data=training_time)
        model.save(os.path.join(os.path.join(self.config.root_dir,
                   self.config.model_dir_name), self.config.model_name))

        history_path = os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), 'training_history.pkl')

        with open(history_path, 'wb') as file:
            pickle.dump(hist.history, file)


class ModelTrainer_GRU:
    def __init__(self, config: ModelTrainerConfig_GRU):
        self.config = config

    def load_scale_data(self):
        X_train = np.array(pd.read_csv(self.config.X_train_data_path))
        y_train = np.array(pd.read_csv(self.config.y_train_data_path))
        X_test = np.array(pd.read_csv(self.config.X_test_data_path))
        y_test = np.array(pd.read_csv(self.config.y_test_data_path))

        std_x = StandardScaler()
        X_train_scaled = std_x.fit_transform(X_train)
        X_test_scaled = std_x.transform(X_test)

        std_y = StandardScaler()
        y_train_scaled = std_y.fit_transform(y_train)
        y_test_scaled = std_y.transform(y_test)

        np.savetxt(os.path.join(os.path.join(self.config.root_dir,
                   self.config.model_dir_name), "X_test_scaled.csv"), X_test_scaled, delimiter=',')
        np.savetxt(os.path.join(os.path.join(self.config.root_dir,
                   self.config.model_dir_name), "y_test_scaled.csv"), y_test_scaled, delimiter=',')

        joblib.dump(std_x, os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), self.config.x_scaler_name))
        joblib.dump(std_y, os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), self.config.y_scaler_name))

        return X_train_scaled, y_train_scaled

    def create_model(self, past_time_steps, future_time_steps):

        model = Sequential()

        model.add(tf.keras.layers.GRU(64, return_sequences=True,
                  input_shape=(past_time_steps+2, 1)))
        model.add(tf.keras.layers.GRU(32, return_sequences=True))
        model.add(tf.keras.layers.GRU(8))
        model.add(tf.keras.layers.Dense(future_time_steps))

        optimizer = Adam(learning_rate=self.config.learning_rate)
        model.compile(loss='mse', optimizer=optimizer,
                      metrics=[RootMeanSquaredError()])

        return model

    def train(self, X_train_scaled, y_train_scaled):

        X_train, X_val, y_train, y_val = train_test_split(
            X_train_scaled, y_train_scaled, test_size=0.2, random_state=42)
        model = self.create_model(self.config.horizon, self.config.horizon)
        early_stopping = tf.keras.callbacks.EarlyStopping(
            monitor='val_loss', patience=self.config.early_stopping, mode='min')

        start_gru = time.time()
        hist = model.fit(X_train, y_train, validation_data=(
            X_val, y_val), epochs=self.config.epochs, callbacks=[early_stopping])
        end_gru = time.time()

        training_time = end_gru - start_gru
        training_time = {"training time": training_time}
        save_json(path=Path(os.path.join(os.path.join(self.config.root_dir,
                  self.config.model_dir_name), self.config.runtime_name)), data=training_time)
        model.save(os.path.join(os.path.join(self.config.root_dir,
                   self.config.model_dir_name), self.config.model_name))

        history_path = os.path.join(os.path.join(
            self.config.root_dir, self.config.model_dir_name), 'training_history.pkl')

        with open(history_path, 'wb') as file:
            pickle.dump(hist.history, file)
