from src.mlProject.constants import *
from src.mlProject.utils.common import read_yaml, create_directories
from src.mlProject.entity.config_entity import DataIngestionConfig
from src.mlProject.entity.config_entity import DataValidationConfig
from src.mlProject.entity.config_entity import DataTransformationconfig
from src.mlProject.entity.config_entity import ModelTrainerConfig_LR, ModelTrainerConfig_SVR, ModelTrainerConfig_XGBoost, ModelTrainerConfig_CNN, ModelTrainerConfig_LSTM, ModelTrainerConfig_GRU
from src.mlProject.entity.config_entity import ModelEvaluationConfig_LR , ModelEvaluationConfig_SVR, ModelEvaluationConfig_XGBoost, ModelEvaluationConfig_CNN, ModelEvaluationConfig_LSTM, ModelEvaluationConfig_GRU
import os


class ConfigurationManager:
    def __init__(
            self,
            config_filepath=CONFIG_FILE_PATH,
            params_filepath=PARAMS_FILE_PATH,
            schema_filepath=SCHEMA_FILE_PATH):

        self.config = read_yaml(config_filepath)
        self.params = read_yaml(params_filepath)
        self.schema = read_yaml(schema_filepath)

        create_directories([self.config.artifacts_root])

    def get_data_ingestion_config(self) -> DataIngestionConfig:
        config = self.config.data_ingestion

        create_directories([config.root_dir])

        data_ingestion_config = DataIngestionConfig(
            root_dir=config.root_dir,
            source_URL=config.source_URL,
            local_data_file=config.local_data_file,
            unzip_dir=config.unzip_dir
        )

        return data_ingestion_config

    def get_data_validation_config(self) -> DataValidationConfig:
        config = self.config.data_validation
        schema = self.schema.COLUMNS

        create_directories([config.root_dir])

        data_validation_config = DataValidationConfig(
            root_dir=config.root_dir,
            STATUS_FILE=config.STATUS_FILE,
            unzip_data_dir=config.unzip_data_dir,
            all_schema=schema,
        )
        return data_validation_config

    def get_data_transformation_config(self) -> DataTransformationconfig:
        config = self.config.data_transformation
        horizon = self.params.horizon.h
        create_directories([config.root_dir])

        data_transformation_config = DataTransformationconfig(
            root_dir=config.root_dir,
            data_path=config.data_path,
            horizon=horizon
        )
        return data_transformation_config

    ####################### Models #############################

    def get_model_trainer_config_LR(self) -> ModelTrainerConfig_LR:
        config = self.config.model_trainer_LR

        create_directories([config.root_dir])
        create_directories(
            [os.path.join(config.root_dir, config.model_dir_name)])
        model_trainer_config = ModelTrainerConfig_LR(
            root_dir=config.root_dir,
            X_train_data_path=config.X_train_data_path,
            y_train_data_path=config.y_train_data_path,
            model_name=config.model_name,
            model_dir_name=config.model_dir_name,
            runtime_name=config.runtime_name
        )
        return model_trainer_config

    def get_model_trainer_config_SVR(self) -> ModelTrainerConfig_SVR:
        config = self.config.model_trainer_svr
        params = self.params.SVR

        create_directories([config.root_dir])
        create_directories(
            [os.path.join(config.root_dir, config.model_dir_name)])
        model_trainer_config = ModelTrainerConfig_SVR(
            root_dir=config.root_dir,
            model_dir_name=config.model_dir_name,
            X_train_data_path=config.X_train_data_path,
            y_train_data_path=config.y_train_data_path,
            X_test_data_path=config.X_test_data_path,
            y_test_data_path=config.y_test_data_path,
            model_name=config.model_name,
            x_scaler_name=config.x_scaler_name,
            y_scaler_name=config.y_scaler_name,
            c=params.c,
            gamma=params.gamma,
            runtime_name=config.runtime_name
        )
        return model_trainer_config

    def get_model_trainer_config_XGBoost(self) -> ModelTrainerConfig_XGBoost:
        config = self.config.model_trainer_xgboost
        params = self.params.XGBoost

        create_directories([config.root_dir])
        create_directories(
            [os.path.join(config.root_dir, config.model_dir_name)])
        model_trainer_config = ModelTrainerConfig_XGBoost(
            root_dir=config.root_dir,
            model_dir_name=config.model_dir_name,
            X_train_data_path=config.X_train_data_path,
            y_train_data_path=config.y_train_data_path,
            X_test_data_path=config.X_test_data_path,
            y_test_data_path=config.y_test_data_path,
            model_name=config.model_name,
            x_scaler_name=config.x_scaler_name,
            y_scaler_name=config.y_scaler_name,
            n_estimators=params.n_estimators,
            early_stopping_rounds=params.early_stopping_rounds,
            runtime_name=config.runtime_name
        )
        return model_trainer_config

    def get_model_trainer_config_CNN(self) -> ModelTrainerConfig_CNN:
        config = self.config.model_trainer_cnn
        params = self.params.horizon
        cnn_params = self.params.CNN

        create_directories([config.root_dir])
        create_directories(
            [os.path.join(config.root_dir, config.model_dir_name)])
        model_trainer_config = ModelTrainerConfig_CNN(
            root_dir=config.root_dir,
            model_dir_name=config.model_dir_name,
            X_train_data_path=config.X_train_data_path,
            y_train_data_path=config.y_train_data_path,
            X_test_data_path=config.X_test_data_path,
            y_test_data_path=config.y_test_data_path,
            model_name=config.model_name,
            x_scaler_name=config.x_scaler_name,
            y_scaler_name=config.y_scaler_name,
            horizon=params.h,
            runtime_name=config.runtime_name,
            early_stopping=cnn_params.early_stopping,
            epochs=cnn_params.epochs,
            learning_rate=cnn_params.lr

        )
        return model_trainer_config

    def get_model_trainer_config_LSTM(self) -> ModelTrainerConfig_LSTM:
        config = self.config.model_trainer_lstm
        params = self.params.horizon
        cnn_params = self.params.LSTM

        create_directories([config.root_dir])
        create_directories(
            [os.path.join(config.root_dir, config.model_dir_name)])
        model_trainer_config = ModelTrainerConfig_LSTM(
            root_dir=config.root_dir,
            model_dir_name=config.model_dir_name,
            X_train_data_path=config.X_train_data_path,
            y_train_data_path=config.y_train_data_path,
            X_test_data_path=config.X_test_data_path,
            y_test_data_path=config.y_test_data_path,
            model_name=config.model_name,
            x_scaler_name=config.x_scaler_name,
            y_scaler_name=config.y_scaler_name,
            horizon=params.h,
            runtime_name=config.runtime_name,
            early_stopping=cnn_params.early_stopping,
            epochs=cnn_params.epochs,
            learning_rate=cnn_params.lr

        )
        return model_trainer_config

    def get_model_trainer_config_GRU(self) -> ModelTrainerConfig_GRU:
        config = self.config.model_trainer_gru
        params = self.params.horizon
        cnn_params = self.params.GRU

        create_directories([config.root_dir])
        create_directories(
            [os.path.join(config.root_dir, config.model_dir_name)])
        model_trainer_config = ModelTrainerConfig_GRU(
            root_dir=config.root_dir,
            model_dir_name=config.model_dir_name,
            X_train_data_path=config.X_train_data_path,
            y_train_data_path=config.y_train_data_path,
            X_test_data_path=config.X_test_data_path,
            y_test_data_path=config.y_test_data_path,
            model_name=config.model_name,
            x_scaler_name=config.x_scaler_name,
            y_scaler_name=config.y_scaler_name,
            horizon=params.h,
            runtime_name=config.runtime_name,
            early_stopping=cnn_params.early_stopping,
            epochs=cnn_params.epochs,
            learning_rate=cnn_params.lr

        )
        return model_trainer_config

    ######################## MOdels #################################

    def get_model_evaluation_config_LR(self) -> ModelEvaluationConfig_LR:
        config = self.config.model_evaluation_LR

        create_directories([config.root_dir])
        create_directories([os.path.join(config.root_dir,config.model_dir_name)])
        
        model_evaluation_config = ModelEvaluationConfig_LR(
            root_dir=config.root_dir,
            model_dir_name=config.model_dir_name,
            X_test_data_path=config.X_test_data_path,
            y_test_data_path=config.y_test_data_path,
            model_path=config.model_path,
            metric_file= config.metric_file,
            mlflow_uri="https://dagshub.com/mr1aarb23/Teraflow-Forecast-Pipeline.mlflow" 
        )
        
        return model_evaluation_config
    
    def get_model_evaluation_config_SVR(self) -> ModelEvaluationConfig_SVR:
        config = self.config.model_evaluation_SVR
        params = self.params.SVR
        
        create_directories([config.root_dir])
        create_directories([os.path.join(config.root_dir,config.model_dir_name)])
        
        model_evaluation_config = ModelEvaluationConfig_SVR(
            root_dir=config.root_dir,
            model_dir_name= config.model_dir_name,
            X_test_data_path=config.X_test_data_path,
            y_test_data_path=config.y_test_data_path,
            X_test_scaled_data_path=config.X_test_scaled_data_path,
            y_test_scaled_data_path=config.y_test_scaled_data_path,
            model_path=config.model_path,
            y_scaler_path=config.y_scaler_path,
            all_params = params,
            metric_file= config.metric_file,
            mlflow_uri="https://dagshub.com/mr1aarb23/Teraflow-Forecast-Pipeline.mlflow" 
        )
        
        return model_evaluation_config
    
    def get_model_evaluation_config_XGBoost(self) -> ModelEvaluationConfig_XGBoost:
        config = self.config.model_evaluation_XGBoost
        params = self.params.XGBoost

        create_directories([config.root_dir])
        create_directories([os.path.join(config.root_dir,config.model_dir_name)])
        
        model_evaluation_config = ModelEvaluationConfig_XGBoost(
            root_dir=config.root_dir,
            model_dir_name=config.model_dir_name,
            X_test_data_path=config.X_test_data_path,
            y_test_data_path=config.y_test_data_path,
            X_test_scaled_data_path=config.X_test_scaled_data_path,
            y_test_scaled_data_path=config.y_test_scaled_data_path,
            y_scaler_path=config.y_scaler_path,
            model_path=config.model_path,
            all_params=params,
            metric_file= config.metric_file,
            mlflow_uri="https://dagshub.com/mr1aarb23/Teraflow-Forecast-Pipeline.mlflow" 
        )
        
        return model_evaluation_config
    
    def get_model_evaluation_config_CNN(self) -> ModelEvaluationConfig_CNN:
        config = self.config.model_evaluation_CNN
        params = self.params.CNN

        create_directories([config.root_dir])
        create_directories([os.path.join(config.root_dir,config.model_dir_name)])
        
        model_evaluation_config = ModelEvaluationConfig_CNN(
            root_dir=config.root_dir,
            model_dir_name=config.model_dir_name,
            X_test_data_path=config.X_test_data_path,
            y_test_data_path=config.y_test_data_path,
            X_test_scaled_data_path=config.X_test_scaled_data_path,
            y_test_scaled_data_path=config.y_test_scaled_data_path,
            y_scaler_path=config.y_scaler_path,
            model_path=config.model_path,
            all_params=params,
            metric_file= config.metric_file,
            mlflow_uri="https://dagshub.com/mr1aarb23/Teraflow-Forecast-Pipeline.mlflow" 
        )
        
        return model_evaluation_config
    
    def get_model_evaluation_config_LSTM(self) -> ModelEvaluationConfig_LSTM:
        config = self.config.model_evaluation_LSTM
        params = self.params.LSTM

        create_directories([config.root_dir])
        create_directories([os.path.join(config.root_dir,config.model_dir_name)])
        
        model_evaluation_config = ModelEvaluationConfig_LSTM(
            root_dir=config.root_dir,
            model_dir_name=config.model_dir_name,
            X_test_data_path=config.X_test_data_path,
            y_test_data_path=config.y_test_data_path,
            X_test_scaled_data_path=config.X_test_scaled_data_path,
            y_test_scaled_data_path=config.y_test_scaled_data_path,
            y_scaler_path=config.y_scaler_path,
            model_path=config.model_path,
            all_params=params,
            metric_file= config.metric_file,
            mlflow_uri="https://dagshub.com/mr1aarb23/Teraflow-Forecast-Pipeline.mlflow" 
        )
        
        return model_evaluation_config
    
    def get_model_evaluation_config_GRU(self) -> ModelEvaluationConfig_GRU:
        config = self.config.model_evaluation_GRU
        params = self.params.GRU

        create_directories([config.root_dir])
        create_directories([os.path.join(config.root_dir,config.model_dir_name)])
        
        model_evaluation_config = ModelEvaluationConfig_GRU(
            root_dir=config.root_dir,
            model_dir_name=config.model_dir_name,
            X_test_data_path=config.X_test_data_path,
            y_test_data_path=config.y_test_data_path,
            X_test_scaled_data_path=config.X_test_scaled_data_path,
            y_test_scaled_data_path=config.y_test_scaled_data_path,
            y_scaler_path=config.y_scaler_path,
            model_path=config.model_path,
            all_params=params,
            metric_file= config.metric_file,
            mlflow_uri="https://dagshub.com/mr1aarb23/Teraflow-Forecast-Pipeline.mlflow" 
        )
        
        return model_evaluation_config