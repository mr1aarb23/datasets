from src.mlProject.config.configuration import ConfigurationManager
from src.mlProject.components.model_trainer import ModelTrainer_LR , ModelTrainer_SVR, ModelTrainer_XGBoost, ModelTrainer_CNN, ModelTrainer_LSTM, ModelTrainer_GRU
from src.mlProject.utils import logger
from pathlib import Path

STAGE_NAME = "Model Trainer stage"


class ModelTrainerPipeline():
    def __init__(self):
        pass
    def main(self):
        config = ConfigurationManager()
        model_trainer_config = config.get_model_trainer_config_LR()
        model_trainer_config = ModelTrainer_LR(config=model_trainer_config)
        X_train_scaled,y_train_scaled = model_trainer_config.load_data()
        model_trainer_config.train(X_train_scaled,y_train_scaled)
    
        config = ConfigurationManager()
        model_trainer_config = config.get_model_trainer_config_SVR()
        model_trainer_config = ModelTrainer_SVR(config=model_trainer_config)
        X_train_scaled,y_train_scaled = model_trainer_config.load_scale_data()
        model_trainer_config.train(X_train_scaled,y_train_scaled)
        
        config = ConfigurationManager()
        model_trainer_config = config.get_model_trainer_config_XGBoost()
        model_trainer_config = ModelTrainer_XGBoost(config=model_trainer_config)
        X_train_scaled,y_train_scaled = model_trainer_config.load_scale_data()
        model_trainer_config.train(X_train_scaled,y_train_scaled)
        
        config = ConfigurationManager()
        model_trainer_config = config.get_model_trainer_config_CNN()
        model_trainer_config = ModelTrainer_CNN(config=model_trainer_config)
        X_train_scaled,y_train_scaled = model_trainer_config.load_scale_data()
        model_trainer_config.train(X_train_scaled,y_train_scaled)
        
        config = ConfigurationManager()
        model_trainer_config = config.get_model_trainer_config_LSTM()
        model_trainer_config = ModelTrainer_LSTM(config=model_trainer_config)
        X_train_scaled,y_train_scaled = model_trainer_config.load_scale_data()
        model_trainer_config.train(X_train_scaled,y_train_scaled)
        
        config = ConfigurationManager()
        model_trainer_config = config.get_model_trainer_config_GRU()
        model_trainer_config = ModelTrainer_GRU(config=model_trainer_config)
        X_train_scaled,y_train_scaled = model_trainer_config.load_scale_data()
        model_trainer_config.train(X_train_scaled,y_train_scaled)
        
if __name__ == '__main__':
    try:
        logger.info(f">>>>>> stage {STAGE_NAME} started <<<<<<")
        obj = ModelTrainerPipeline()
        obj.main()
        logger.info(
            f">>>>>> stage {STAGE_NAME} completed <<<<<< \n\n x========x")
    except Exception as e:
        logger.exception(e)
        raise e
