from src.mlProject.config.configuration import ConfigurationManager
from src.mlProject.components.model_evaluation import ModelEvaluation_LR , ModelEvaluation_SVR, ModelEvaluation_XGBoost, ModelEvaluation_CNN, ModelEvaluation_LSTM, ModelEvaluation_GRU
from src.mlProject.utils import logger

STAGE_NAME = "Model Evaluation stage"


class ModelEvaluationPipeline():
    def __init__(self):
        pass
    def main(self):
        config = ConfigurationManager()
        model_evaluation_config = config.get_model_evaluation_config_LR()
        model_evaluation_config = ModelEvaluation_LR(config=model_evaluation_config)
        model_evaluation_config.log_into_mlflow()
        
        config = ConfigurationManager()
        model_evaluation_config = config.get_model_evaluation_config_SVR()
        model_evaluation_config = ModelEvaluation_SVR(config=model_evaluation_config)
        model_evaluation_config.log_into_mlflow()
        
        config = ConfigurationManager()
        model_evaluation_config = config.get_model_evaluation_config_XGBoost()
        model_evaluation_config = ModelEvaluation_XGBoost(config=model_evaluation_config)
        model_evaluation_config.log_into_mlflow()
        
        config = ConfigurationManager()
        model_evaluation_config = config.get_model_evaluation_config_CNN()
        model_evaluation_config = ModelEvaluation_CNN(config=model_evaluation_config)
        model_evaluation_config.log_into_mlflow()
        
        config = ConfigurationManager()
        model_evaluation_config = config.get_model_evaluation_config_LSTM()
        model_evaluation_config = ModelEvaluation_LSTM(config=model_evaluation_config)
        model_evaluation_config.log_into_mlflow()
        
        config = ConfigurationManager()
        model_evaluation_config = config.get_model_evaluation_config_GRU()
        model_evaluation_config = ModelEvaluation_GRU(config=model_evaluation_config)
        model_evaluation_config.log_into_mlflow()

if __name__ == '__main__':
    try:
        logger.info(f">>>>>> stage {STAGE_NAME} started <<<<<<")
        obj = ModelEvaluationPipeline()
        obj.main()
        logger.info(
            f">>>>>> stage {STAGE_NAME} completed <<<<<< \n\n x========x")
    except Exception as e:
        logger.exception(e)
        raise e
