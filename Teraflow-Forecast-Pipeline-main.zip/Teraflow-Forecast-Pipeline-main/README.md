# Teraflow-Forecast-Pipeline

MLFLOW_TRACKING_URI=https://dagshub.com/mr1aarb23/Teraflow-Forecast-Pipeline.mlflow \
MLFLOW_TRACKING_USERNAME=mr1aarb23 \
MLFLOW_TRACKING_PASSWORD=75375de53126c0efd2af4abfd59e8ab3eb6a0594 \
python script.py

```bash
set MLFLOW_TRACKING_URI=https://dagshub.com/mr1aarb23/Teraflow-Forecast-Pipeline.mlflow

set MLFLOW_TRACKING_USERNAME=mr1aarb23

set MLFLOW_TRACKING_PASSWORD=75375de53126c0efd2af4abfd59e8ab3eb6a0594
```